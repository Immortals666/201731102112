import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;

/**
 * 
 */

/**
 * @author Administrator
 *
 */
public class Core {
    //�������ⲿ����ʵ�ֹ��ܣ�
	public boolean MainCore(String read){
		String resultfile;
		String filePath;
		String SF=null;
		String[] ml=read.split("\\s+");
		if(ml.length<=2 && ml.length>0){
			filePath=ml[0].substring(0,ml[0].length());
			resultfile=ml[1].substring(0,ml[1].length());
			
		}else if(ml.length>2 && ml.length<=3){
			filePath=ml[0].substring(0,ml[0].length());
			resultfile=ml[1].substring(0,ml[1].length());
			SF=ml[2].substring(0,ml[2].length());	
		}else{
			System.out.println("��ʽ������󣬳������");
			return false;
		}
		
		 return Write(Sortt(Read(filePath,SF)),resultfile);
	}
	//�ṩ�ļ�Ŀ¼����ԭ�ļ��ж�������
	private ArrayList<Pshen> Read(String filePath,String SF){
	   ArrayList<Pshen> shenadd=new ArrayList<Pshen>();
	   //***
		   String shen;
		   String diqu;
		   String renshu;
		   try {
		    File file = new File(filePath);
		    if(file.isFile() && file.exists()) {
		      InputStreamReader isr = new InputStreamReader(new FileInputStream(file), "gb2312");
		      BufferedReader br = new BufferedReader(isr);
		      String lineTxt = null;
		     while ((lineTxt = br.readLine()) != null) {
		        String[] ax=lineTxt.split("\\s+");
		        shen=ax[0];
		        diqu=ax[1];
		        renshu=ax[2];
		        if( SF!=null){
		        	if(SF.equals(shen)){
		        		shenadd=addArraylist(shenadd,shen,diqu,renshu);
		        		
		        		
		        	}
		        }else{
		        	  shenadd=addArraylist(shenadd,shen,diqu,renshu);
		        }
		      }
		      br.close();
		      return shenadd;
		    } else {
		      System.out.println("�ļ�������!");
		      return null;
		    }
		  } catch (Exception e) {
		    System.out.println("�ļ���ȡ����!");
		    return null;
		  } 
	   //***
   }
   //������д�뵽�ļ��У�������õ�Ŀ¼���ļ������ڣ�����´���һ������д��
    private boolean Write(ArrayList<Pshen> shenadd ,String resultfile){
	   //****
	   
		
			// TODO Auto-generated method stub
			  File record = new File(resultfile);//��¼����ļ�
		        try {
		            if (!record.exists()) {

		                File dir = new File(record.getParent());
		                dir.mkdirs();
		                record.createNewFile();
		            }
		            FileWriter writer = null;
		            try {
		                // ��һ��д�ļ��������캯���еĵڶ�������true��ʾ��׷����ʽд�ļ�
		                writer = new FileWriter(record, true);
		                for(int j=0;j<shenadd.size();j++){
		                	writer.write(shenadd.get(j).sname+"  ");
		                	writer.write(shenadd.get(j).samount+"\r\n");
		                	for(int w=0;w<shenadd.get(j).diquadd.size();w++){
		                		writer.write(shenadd.get(j).diquadd.get(w).dname+"  ");
		                		writer.write(shenadd.get(j).diquadd.get(w).damount+"\r\n");
		                	}
		                }
		             return true;
		            } catch (IOException e) {
		                e.printStackTrace();
		                return false;
		            } finally {
		                try {
		                    if (writer != null) {
		                        writer.close();
		                    }
		                } catch (IOException e) {
		                    e.printStackTrace();
		                }
		            }
		        } catch (Exception e) {
		            System.out.println("��¼����ʧ��");
		            return true;
		        }
		

	   //*******
	   
   }
   //ʵ�ְ���ʡ�ݺ͵�������������
   private ArrayList<Pshen> Sortt(ArrayList<Pshen> shenadd){
	   //***
	   for(int i=0;i<shenadd.size();i++){
	    	  for(int j=i+1;j<shenadd.size();j++){
	    		  if(shenadd.get(i).samount<shenadd.get(j).samount){
	    			  Collections.swap(shenadd, i, j);
	    		  }
	    	  }
	      }
	      //
	      for(int x=0;x<shenadd.size();x++){
	    	  for(int i=0;i<shenadd.get(x).diquadd.size();i++){
		    	  for(int j=i+1;j<shenadd.get(x).diquadd.size();j++){
		    		  if(shenadd.get(x).diquadd.get(i).damount<shenadd.get(x).diquadd.get(j).damount){
		    			  Collections.swap(shenadd.get(x).diquadd, i, j);
		    		  }
		    	  }
		      }
	      }
	   //***
	   return shenadd;
   }
   //ʵ�ֽ����������ݼ��뵽�����Ķ�̬�����С�
   private ArrayList<Pshen> addArraylist(ArrayList<Pshen> shenadd,String shen,String diqu,String renshu){
	    Pshen danshen=new Pshen();
	    Ddiqu dandiqu=new Ddiqu();
	    if(shenadd.size()==0){
        	dandiqu.dname=diqu;
        	dandiqu.damount=Integer.parseInt(renshu);
        	danshen.sname=shen;
        	danshen.samount=Integer.parseInt(renshu);
        	danshen.diquadd.add(dandiqu);
        	shenadd.add(danshen);
        }else{
        		if(shen.equals(shenadd.get(shenadd.size()-1).sname)){
        		dandiqu.dname=diqu;
		        dandiqu.damount=Integer.parseInt(renshu);
		        shenadd.get(shenadd.size()-1).samount += Integer.parseInt(renshu);
		        shenadd.get(shenadd.size()-1).diquadd.add(dandiqu);
        		}else{
        			dandiqu.dname=diqu;
		        	dandiqu.damount=Integer.parseInt(renshu);
		        	danshen.sname=shen;
		        	danshen.samount=Integer.parseInt(renshu);
		        	danshen.diquadd.add(dandiqu);
		        	shenadd.add(danshen);
		        	
        		}
        	}
	   return shenadd;
   }
   
}
