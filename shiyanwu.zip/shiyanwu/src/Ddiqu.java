
public class Ddiqu {
     String dname;
     int damount;
}
