import java.util.ArrayList;
public class Pshen {
    String sname;
    int  samount=0;
    ArrayList<Ddiqu> diquadd=new ArrayList<Ddiqu>();
}
